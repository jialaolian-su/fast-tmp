from starlette.middleware.gzip import GZipMiddleware  # noqa
