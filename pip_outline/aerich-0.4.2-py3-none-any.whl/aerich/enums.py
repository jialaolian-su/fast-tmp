from enum import Enum


class Color(str, Enum):
    green = "green"
    red = "red"
    yellow = "yellow"
