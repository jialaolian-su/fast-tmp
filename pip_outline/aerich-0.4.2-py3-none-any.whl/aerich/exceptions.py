class NotSupportError(Exception):
    """
    raise when features not support
    """
